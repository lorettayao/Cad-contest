#pragma once
#include "global.h"

void init_glorot(s_data2d_ds &weight);

void init_zero(s_data1d_ds &bias);
